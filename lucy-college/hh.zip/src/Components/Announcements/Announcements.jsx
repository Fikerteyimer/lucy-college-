import React from "react";

const Announcements=()=>{
    return(
      <div>
        
      </div>
    );
}
export default Announcements;