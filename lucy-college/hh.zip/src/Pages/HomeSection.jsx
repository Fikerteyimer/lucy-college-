import Hero from "../Components/Hero/Hero.jsx";

const Home = () => {
  return (
    <>
      <Hero />
    </>
  );
};

export default Home;
