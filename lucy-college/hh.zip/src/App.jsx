import React from "react";
import {createBrowserRouter, createRoutesFromElements, Route,RouterProvider,Routes} from 'react-router-dom';
import Navbar from "./Components/Navbar/Navbar.jsx";
import HomeSection from './Pages/HomeSection.jsx';
import AboutSection from './Pages/AboutSection.jsx';
import ProgramsSection from './Pages/ProgramsSection.jsx';
import AnnouncementsSection from './Pages/AnnouncementsSection.jsx';
import ContactSection from "./Pages/ContactSection.jsx";
import RootLayout from "./Layout/RootLayout.jsx";

const App=()=>{
  const router=createBrowserRouter(
    createRoutesFromElements(<Route path='/' element={<RootLayout/>}>
          <Route index element={<HomeSection/>}/>
           <Route path='About' element={<AboutSection/>}/>
           <Route path='Programs' element={<ProgramsSection/>}/>
           <Route path='Announcements' element={<AnnouncementsSection/>}/>
           <Route path='Contact' element={<ContactSection/>}/>

      </Route>
    )
  )
  return(
    <div>
    <RouterProvider router={router}/>
   </div>

  )
}
export default App;